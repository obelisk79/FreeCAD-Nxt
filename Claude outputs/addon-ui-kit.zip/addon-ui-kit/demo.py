"""Show a FreeCAD task dialog built from the kit, to try it or copy from.

Run it from FreeCAD's Python console:

    import runpy
    runpy.run_path("/path/to/addon-ui-kit/demo.py", run_name="__main__")

The values live in a small Python object (`Demo`); in your addon that
is the bridge to your document objects.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import FreeCADGui as Gui
from PySide6 import QtCore, QtWidgets

KIT = Path(__file__).resolve().parent
sys.path.insert(0, str(KIT))

from addonkit import task_panel, theme, views  # noqa: E402

#: Wait before ordering Tab, so the dialog has laid itself out.
LAYOUT_MS = 0


class Demo(QtCore.QObject):
    """The values the panel shows; QML reads and sets them only here."""

    changed = QtCore.Signal()

    def __init__(self, parent: QtCore.QObject | None = None) -> None:
        super().__init__(parent)
        self._side, self._kind = "One", "Length"
        self._length, self._merge = "10", True

    @QtCore.Property(str, notify=changed)
    def side(self) -> str:
        return self._side

    @QtCore.Property(str, notify=changed)
    def kind(self) -> str:
        return self._kind

    @QtCore.Property(str, notify=changed)
    def length(self) -> str:
        return self._length

    @QtCore.Property(bool, notify=changed)
    def merge(self) -> bool:
        return self._merge

    @QtCore.Slot(str)
    def setSide(self, value: str) -> None:  # noqa: N802 - QML API
        self._side = value
        self.changed.emit()

    @QtCore.Slot(str)
    def setKind(self, value: str) -> None:  # noqa: N802 - QML API
        self._kind = value
        self.changed.emit()

    @QtCore.Slot(str)
    def setLength(self, value: str) -> None:  # noqa: N802 - QML API
        if value != self._length:
            self._length = value
            self.changed.emit()

    @QtCore.Slot(bool)
    def setMerge(self, on: bool) -> None:  # noqa: N802 - QML API
        self._merge = on
        self.changed.emit()

    def apply_pending(self) -> None:
        """Nothing is queued here; your bridge runs its queued edits."""


class DemoTask:
    """A task dialog whose form is a QML view."""

    def __init__(self) -> None:
        self.form = QtWidgets.QWidget()
        self.form.setWindowTitle("Addon kit demo")
        layout = QtWidgets.QVBoxLayout(self.form)
        layout.setContentsMargins(0, 0, 0, 0)
        self.theme = theme.Theme(self.form, theme.find_reference_widget(
            Gui.getMainWindow()))
        self.demo = Demo(self.form)
        self.view = views.make_view(
            self.form, KIT / "DemoPanel.qml",
            {"theme": self.theme, "demo": self.demo})
        self.view.setMinimumHeight(int(self.view.initialSize().height()))
        layout.addWidget(self.view)
        QtCore.QTimer.singleShot(LAYOUT_MS, self._wire)

    def _wire(self) -> None:
        task_panel.tab_in_order(self.view)
        self._confirm = task_panel.ApplyOnConfirm(
            self.view, self.demo.apply_pending)

    def accept(self) -> bool:
        Gui.Control.closeDialog()
        return True

    def reject(self) -> bool:
        Gui.Control.closeDialog()
        return True


def run() -> Any:
    task = DemoTask()
    Gui.Control.showDialog(task)
    return task


if __name__ == "__main__":
    run()
