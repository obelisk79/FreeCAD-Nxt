"""A QML view inside a FreeCAD task dialog: Tab order and OK.

From the FreeCAD-Nxt addon (LGPL-2.1-or-later); adapted to stand alone.
"""

from __future__ import annotations

import contextlib
from collections.abc import Callable
from typing import Any

import FreeCADGui as Gui
from PySide6 import QtCore, QtWidgets


def task_view() -> QtWidgets.QWidget | None:
    """FreeCAD's task view (the Tasks panel), if it exists."""
    main = Gui.getMainWindow()
    if main is None:
        return None
    for widget in main.findChildren(QtWidgets.QWidget):
        if widget.metaObject().className() == "Gui::TaskView::TaskView":
            return widget
    return None


def tab_in_order(view: QtWidgets.QWidget) -> None:
    """Tab through the task panel in reading order, `view` included.

    Left to right, top to bottom: from your QML view on to the dialog's
    own options and OK, not off to the rest of the window, which is where
    the focus chain leads from a view added after the dialog was built.
    Call it after the panel is shown, and again whenever it is laid out
    anew.
    """
    tasks = task_view()
    if tasks is None:
        return
    found = []
    for widget in tasks.findChildren(QtWidgets.QWidget):
        if widget is view or (
                widget.isVisibleTo(tasks)
                and widget.focusPolicy() & QtCore.Qt.FocusPolicy.TabFocus
                and not view.isAncestorOf(widget)):
            at = widget.mapTo(tasks, QtCore.QPoint(0, 0))
            found.append((at.y(), at.x(), widget))
    found.sort(key=lambda f: (f[0], f[1]))
    ordered = [w for _y, _x, w in found]
    for first, second in zip(ordered, ordered[1:]):
        QtWidgets.QWidget.setTabOrder(first, second)


class ApplyOnConfirm(QtCore.QObject):
    """Apply what is typed in `view` before the dialog's OK or Apply runs.

    Those buttons take no focus, so a field being typed in never loses
    it and never commits. Pressing one moves focus out of the QML (each
    field commits on focus loss) and calls `apply_pending`, which should
    run any edits still queued.
    """

    def __init__(self, view: Any, apply_pending: Callable[[], None]) -> None:
        super().__init__(view)
        self._view = view
        self._apply = apply_pending
        tasks = task_view()
        boxes = (tasks.findChildren(QtWidgets.QDialogButtonBox)
                 if tasks is not None else [])
        roles = (QtWidgets.QDialogButtonBox.ButtonRole.AcceptRole,
                 QtWidgets.QDialogButtonBox.ButtonRole.ApplyRole)
        for box in boxes:
            for button in box.buttons():
                if box.buttonRole(button) in roles:
                    button.installEventFilter(self)

    def eventFilter(self, _obj: Any, event: Any) -> bool:  # noqa: N802
        if event.type() in (QtCore.QEvent.Type.MouseButtonPress,
                            QtCore.QEvent.Type.KeyPress):
            with contextlib.suppress(RuntimeError):
                root = self._view.rootObject()
                if root is not None:
                    root.forceActiveFocus()     # the field keeps its edit
                self._apply()
        return False
