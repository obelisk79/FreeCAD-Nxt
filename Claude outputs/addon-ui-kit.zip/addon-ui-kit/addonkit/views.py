"""QML views inside FreeCAD's QtWidgets interface, and their keyboard focus.

From the FreeCAD-Nxt addon (LGPL-2.1-or-later); adapted to stand alone.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any

from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtQuickWidgets import QQuickWidget

#: The folder that holds the AddonKit QML module.
QML_DIR = Path(__file__).resolve().parent.parent / "qml"


class QmlLoadError(RuntimeError):
    """A QML file failed to load; the message lists QML's errors."""


def make_view(parent: QtWidgets.QWidget | None, source: Path,
              context: Mapping[str, Any], *, floating: bool = False,
              prepare: Callable[[Any], None] | None = None) -> QQuickWidget:
    """A QQuickWidget showing the QML file `source`.

    `context` becomes QML context properties (pass the Theme as "theme").
    A floating view sizes itself to its QML and is see-through, for use
    over the 3D view.
    """
    view = QQuickWidget(parent)
    mode = QQuickWidget.ResizeMode
    view.setResizeMode(mode.SizeViewToRootObject if floating
                       else mode.SizeRootObjectToView)
    if floating:
        view.setAttribute(QtCore.Qt.WidgetAttribute.WA_AlwaysStackOnTop)
        view.setClearColor(QtGui.QColor(0, 0, 0, 0))
    view.engine().addImportPath(str(QML_DIR))
    root_context = view.rootContext()
    for name, value in context.items():
        root_context.setContextProperty(name, value)
    if prepare is not None:
        prepare(view)
    view.setSource(QtCore.QUrl.fromLocalFile(str(source)))
    if view.status() == QQuickWidget.Status.Error:
        detail = "\n".join(str(e.toString()) for e in view.errors())
        view.deleteLater()
        raise QmlLoadError("%s failed to load:\n%s" % (source, detail))
    LetsGo(view)
    return view


#: How the keyboard leaves a view for good, by the user's hand. Not to a
#: menu it opened, nor as the window loses focus (it comes back to the
#: same field), nor as a dialog rebuilds around the view.
LEAVING = (QtCore.Qt.FocusReason.TabFocusReason,
           QtCore.Qt.FocusReason.BacktabFocusReason,
           QtCore.Qt.FocusReason.MouseFocusReason,
           QtCore.Qt.FocusReason.ShortcutFocusReason)


class LetsGo(QtCore.QObject):
    """A view drops its focused item, and its focus ring, as focus leaves.

    A QQuickWidget keeps its active item when it loses focus, so the ring
    would stay lit on a control the keyboard is no longer in.
    """

    def __init__(self, view: QQuickWidget) -> None:
        super().__init__(view)
        self._view = view
        view.installEventFilter(self)

    def eventFilter(self, _obj: Any, event: Any) -> bool:  # noqa: N802
        if event.type() == QtCore.QEvent.Type.FocusOut \
                and event.reason() in LEAVING:
            root = self._view.rootObject()
            if root is not None:
                root.forceActiveFocus()
        return False


def window_offset(view: Any) -> QtCore.QPointF:
    """Where `view` sits in its top-level window, under Wayland only.

    Wayland places QML popups relative to the window's corner, so shift
    them by this; elsewhere it is zero.
    """
    if view is None or not QtGui.QGuiApplication.platformName() \
            .startswith("wayland"):
        return QtCore.QPointF(0, 0)
    return QtCore.QPointF(view.mapTo(view.window(), QtCore.QPoint(0, 0)))
