"""Addon UI kit: theme, QML views, focus and input helpers."""
