"""Keep the mouse wheel over your widgets from zooming the 3D view.

FreeCAD's overlay manager filters the whole application and sends a wheel
over the 3D view on to the view before a widget drawn over it sees it, so
turning a value also zooms. An application-level filter installed after
FreeCAD's is asked first.

From the FreeCAD-Nxt addon (LGPL-2.1-or-later); adapted to stand alone.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import Any

from PySide6 import QtCore, QtWidgets

#: Called with the widget under the pointer, the wheel's angle (120 per
#: notch) and whether Ctrl was held.
OnWheel = Callable[[QtWidgets.QWidget, int, bool], None]


class WheelGuard(QtCore.QObject):
    """Take each wheel over one of `widgets()` and hand it to `on_wheel`.

    Install once your widgets first appear (after FreeCAD has started),
    and call remove() on teardown.
    """

    def __init__(self, widgets: Callable[[], Iterable[QtWidgets.QWidget]],
                 on_wheel: OnWheel,
                 parent: QtCore.QObject | None = None) -> None:
        super().__init__(parent)
        self._widgets = widgets
        self._on_wheel = on_wheel

    def install(self) -> None:
        QtWidgets.QApplication.instance().installEventFilter(self)

    def remove(self) -> None:
        QtWidgets.QApplication.instance().removeEventFilter(self)

    def _under(self, point: QtCore.QPoint) -> QtWidgets.QWidget | None:
        for widget in self._widgets():
            if widget.isVisible() and widget.rect().contains(
                    widget.mapFromGlobal(point)):
                return widget
        return None

    def eventFilter(self, _obj: Any, event: Any) -> bool:  # noqa: N802
        if event.type() != QtCore.QEvent.Type.Wheel:
            return False
        widget = self._under(event.globalPosition().toPoint())
        if widget is None:
            return False
        self._on_wheel(widget, event.angleDelta().y(), bool(
            event.modifiers() & QtCore.Qt.KeyboardModifier.ControlModifier))
        event.accept()
        return True
