import QtQuick
import AddonKit

// A task-panel card built from the kit's controls. Tab goes through them
// in the order they are declared here: left to right, top to bottom.
Rectangle {
    id: root

    width: 300
    implicitHeight: column.implicitHeight + 2 * pad
    color: theme.background
    readonly property int pad: 8

    Column {
        id: column
        x: root.pad
        y: root.pad
        width: root.width - 2 * root.pad
        spacing: 6

        Segmented {
            width: parent.width
            options: [{value: "One", label: qsTr("One side")},
                      {value: "Two", label: qsTr("Two sides")},
                      {value: "Sym", label: qsTr("Symmetric")}]
            value: demo.side
            onPicked: (chosen) => demo.setSide(chosen)
        }

        Row {
            width: parent.width
            spacing: 6

            DropBox {
                id: kind
                width: 110
                text: demo.kind
                onOpened: {
                    var root = kind.Window.contentItem;
                    var from = kind.Window.activeFocusItem;
                    var list = choices.createObject(root, {
                        options: ["Length", "Through all", "Up to face"],
                        current: demo.kind,
                        below: kind.mapToItem(root, 0, kind.height),
                        anchorHeight: kind.height,
                        minWidth: kind.width
                    });
                    list.chosen.connect((value) => demo.setKind(value));
                    // Back to the dropdown for the keyboard once closed.
                    list.Component.destruction.connect(() => {
                        if (from) from.forceActiveFocus();
                    });
                    list.forceActiveFocus();
                }
            }
            TextField {
                width: parent.width - kind.width - parent.spacing
                text: demo.length
                suffix: "mm"
                stepFor: (modifiers) => (modifiers & Qt.ControlModifier) ? 10 : 1
                onAccepted: demo.setLength(text)
                onStepped: demo.setLength(text)
                // A field keeps what was typed when focus leaves it.
                input.onActiveFocusChanged: if (!input.activeFocus)
                                                demo.setLength(text)
            }
        }

        Toggle {
            width: parent.width
            text: qsTr("Merge faces")
            stored: demo.merge
            onChangedTo: (on) => demo.setMerge(on)
        }
    }

    Component {
        id: choices
        ChoiceList {}
    }
}
