# Addon UI kit for FreeCAD

A spec sheet, a small set of working pieces, and annotated screenshots,
taken from the FreeCAD-Nxt addon. Use it with `freecad-addon-ui-guide.md`
(the rules); this folder shows what following them looks like and gives
working code for the parts that are hard to get right.

**Licence.** The code here comes from FreeCAD-Nxt and is LGPL-2.1-or-later.
Copying it into another addon brings that licence with it; check that it
suits the project, or treat the files as reference and write your own.

## Contents

| Path | What it is |
| --- | --- |
| `addonkit/theme.py`, `addonkit/qss_colours.py` | Colours and metrics read from FreeCAD's active stylesheet, exposed to QML as the `theme` object |
| `addonkit/views.py` | `make_view` (a QML view in a QtWidgets parent) and `LetsGo` (drops the focus ring when the keyboard leaves) |
| `addonkit/task_panel.py` | `tab_in_order` (one Tab chain with FreeCAD's task dialog) and `ApplyOnConfirm` (typed values survive OK) |
| `addonkit/wheel_guard.py` | `WheelGuard`: a wheel over your widget never also zooms the 3D view |
| `qml/AddonKit/` | QML module: `Toggle`, `Segmented`, `DropBox`, `ChoiceList`, `TextField` |
| `demo.py`, `DemoPanel.qml` | A task dialog built from all of the above, to try or copy from |
| `screenshots/` | Annotated screenshots of Nxt's task panel, inspector, keyboard focus and tree |

Try it from FreeCAD's Python console (FreeCAD 1.x, PySide6):

```python
import runpy
runpy.run_path("/path/to/addon-ui-kit/demo.py", run_name="__main__")
```

## Spec sheet

Every size scales from one **row height**, measured from the font of
FreeCAD's own Model tree: font height plus 8 px of padding (3 compact,
14 roomy), at least 20 px. With FreeCAD's default font that is about
26 px. Sizes are rounded to whole pixels.

### Metrics

| Token | Value | At row 26 px |
| --- | --- | --- |
| `rowHeight` | font height + 8, ≥ 20 | 26 |
| `fieldHeight` (text fields, dropdowns) | 0.86 × row | 22 |
| `chipHeight` | 0.68 × row | 18 |
| `iconSize` | 0.72 × row | 19 |
| `markSize` / `markSizeSmall` | 0.62 / 0.50 × row | 16 / 13 |
| `fontRow` (row text) | 0.48 × row | 12 |
| `fontSmall` (controls, labels) | 0.44 × row | 11 |
| `fontAside` (hints, units) | 0.40 × row | 10 |
| Segmented control height | 0.95 × row | 25 |
| Switch track | 1.4 × row wide, 0.72 × row high, fully round | 36 × 19 |
| Switch knob | track height − 4, inset 2; grows to 1.12× on hover; stretches 4 px while pressed | |
| `indent` (tree level) | 14 px | |
| `rowPad` | 4 px | |
| Scroll bar | 10 px | |
| Value column width | 4.4 × row | 114 |

| Shape | Value |
| --- | --- |
| Field and dropdown radius | 3 px |
| Segmented frame radius / option radius | 4 px / 3 px, options 2 px apart inside a 2 px margin |
| Toast and menu radius | 5–6 px |
| Border | 1 px `border`; 2 px `accent` with keyboard focus |
| Switch focus ring | 2 px `accent`, 4 px outside the track (gap 2 px), keyboard focus only |
| Text inset in a field | 6 px from the left edge |
| Card spacing | about 6 px between rows of a card, about one row height between cards |

### Colours

All colours derive from three that FreeCAD's theme provides. Read them
from the stylesheet (`theme.py` does), never from `QApplication.palette()`.

| Source | Where it comes from |
| --- | --- |
| **base** | The background the stylesheet gives FreeCAD's tree (`Gui--TreeWidget`, then `QTreeView`, … down to `QWidget`), with `@Token` values resolved from `BaseApp/Preferences/View`; else the tree's painted background |
| **text** | The stylesheet's `color` for the same widgets; if it fails a 90-step lightness gap against base, near-white or near-black instead |
| **accent** | The palette's `Highlight` (FreeCAD's selection colour); `accentText` is `HighlightedText` |

| Token | Mix | Use |
| --- | --- | --- |
| `background` | base | Panel, field and list background |
| `surface` | base → window colour, 55 % | Card surfaces where the theme distinguishes them |
| `textDim` | text → base, 45 % | Labels of secondary weight, hints, units, arrows |
| `hover` | base → accent, 25 % | Hover fill |
| `pressed` | base → accent, 45 % | Pressed fill |
| `border` | base → text, 18 % | Borders at rest |
| `chip` | base → text, 10 % | Chip, segmented frame and switch-off fills |
| `warning` | base → orange (226, 140, 40), 85 % | Warning marks |
| `danger` | base → red (214, 74, 68), 85 % | Errors, destructive actions |
| `link` | palette `Link` | Text links (Highlight is too faint as text) |
| `dark` | base lightness < 128 | Choose light or dark variants |

Over the 3D view (overlay), panels draw no background; rows sit on a
translucent pill of `base` at 88 % opacity (94 % hovered) with a `text`
border at 14 %.

### Motion and timing

| What | Value |
| --- | --- |
| Hover, colour and focus changes | 70–90 ms |
| Switch knob travel | 110 ms, ease-out cubic |
| Toast fade | 120 ms; stays 6 s, longer while hovered |
| Change announced after the visual change | 30 ms |
| Visual state settles back if the change never lands | 2.5 s |
| Wheel on a field: armed after the pointer rests | 300 ms |
| Wheel on a field: value committed after the wheel rests | 400 ms |
| Live preview budget before falling back to apply-on-release | about 120 ms |

## The QML controls

Each control reads only the `theme` context object, and reports changes by
signal; it never talks to FreeCAD. Your Python bridge object sets values
and handles the signals.

| Control | Bind | Listen | Behaviour built in |
| --- | --- | --- | --- |
| `Toggle` | `stored` (bool), `text` | `changedTo(on)` | Flips at once, signals 30 ms later, settles back after 2.5 s if `stored` never changes; focus ring; hover |
| `Segmented` | `options` (`[{value, label}]`), `value` | `picked(value)` | Same change-first timing; Left/Right step; Tab focus |
| `DropBox` | `text` | `opened()` | Opens on click, Space, Return/Enter, Down, Alt+Down, F4; focus ring |
| `ChoiceList` | `options`, `labels`, `current`, `below`, `anchorHeight`, `minWidth` | `chosen(value)` | Created on the window's content item; closes before emitting; Escape closes |
| `TextField` | `text`, `suffix`, `placeholder`, `stepFor` | `edited`, `accepted`, `dismissed`, `stepped` | Wheel steps the number after a 300 ms rest, commits 400 ms after the wheel stops; Tab focus; content placed inside it comes first in Tab order |

`DemoPanel.qml` shows them together, including returning focus to a
`DropBox` after its list closes, and committing a field when focus leaves
it.

## Screenshots

| File | Shows |
| --- | --- |
| `screenshots/nxt_task_panel_annotated.png` | Nxt's Pad task panel: cards, controls and FreeCAD's kept Preview box |
| `screenshots/nxt_task_panel_focus_annotated.png` | The keyboard focus ring on a dropdown |
| `screenshots/nxt_inspector_annotated.png` | The property inspector, built from the same template |
| `screenshots/nxt_tree_annotated.png` | The model tree: selection, a quiet mark, the rollback bar |
| `screenshots/kit_demo.png` | The kit's demo panel, for comparison |

The screenshots use FreeCAD 27.1's default light theme. The same tokens
produce a matching dark look from a dark stylesheet.
