# UI/UX rules for a FreeCAD addon

Instructions for an AI coding assistant building the interface of a
FreeCAD addon. Put this file in the addon's repository (as `AGENTS.md`,
`CLAUDE.md`, or a file they link to) or paste it into the assistant's
context. Follow every rule unless the maintainer says otherwise. When a
rule and a request conflict, ask.

This file comes with an `addon-ui-kit/` folder. Use it as follows:

- **Sizes, colours and timings:** take them from the spec sheet in
  `addon-ui-kit/README.md`. Do not invent values.
- **Theme, QML controls, Tab order, OK handling, wheel guard:** start from
  the code in `addon-ui-kit/` (`addonkit/` and `qml/AddonKit/`) instead of
  writing them from scratch. `demo.py` shows them wired into a FreeCAD task
  dialog. The code is LGPL-2.1-or-later; confirm with the maintainer
  before copying it into the project.
- **Look:** if you can read images, open `addon-ui-kit/screenshots/` and
  match their layout and density.

## Principles (earlier wins when two conflict)

1. **The interface never waits.** Draw hover, press and the new state in
   the same frame. Start the work the control triggers on a later
   event-loop turn.
2. **Behave like a desktop application.** Standard cursors, double-click
   to open, F2 to rename, Escape to back out, one undo step per action,
   Tab in reading order.
3. **Belong to FreeCAD.** Use FreeCAD's words, colours, commands, dialogs
   and settings. Borrow its pieces; never rebuild them.
4. **Show only what applies.** Hide fields the current mode ignores.
   Show a mark only when something is wrong.
5. **Lose nothing.** Typed values survive focus changes and OK. Automatic
   fixes are undoable in one click and say what they did.
6. **Say what happened in plain words.** Name the thing, what was done,
   what to do next. Errors name the cause.

Two constraints sit beside these:

- **Addon, not fork.** Never require a change to FreeCAD. Leave no trace
  on uninstall.
- **Choose one toolkit and keep it.** Qt Quick (QML) or QtWidgets; if QML,
  use QtWidgets only where FreeCAD requires a widget (a task dialog form,
  a preferences page).

## Responsiveness

- Change the control's look first; run the work after it, from a timer
  owned by a long-lived object. Never use `QTimer.singleShot` with a bound
  method: it can fire into a deleted object.
- Never recompute, open an edit mode, or open a modal dialog inside an
  input handler. FreeCAD's recompute and `setEdit` spin the event loop, so
  mouse events arrive mid-operation. Defer them.
- Coalesce bursts: mark the model dirty on document signals and rebuild
  once on the next turn. Diff the result so views keep scroll and focus.
- Commit continuous input (wheel, drag) once it rests or is released, not
  per step. A drag is one undo step.
- If a live preview cannot stay under about 120 ms, fall back to applying
  on release and report it in the Report view.
- Keep animations 90–150 ms. Animate opacity; never animate a colour
  through `"transparent"` (transparent black in Qt).

## Desktop conventions

| Gesture | Required behaviour |
| --- | --- |
| Pointer over controls | Arrow cursor; pointing hand only on text links |
| Click | Selects through `Gui.Selection`, so all panels agree |
| Double-click | Opens the object for editing |
| F2, or click on an already-selected name | Rename; arm the click only after the double-click interval |
| Escape | Closes the innermost thing only; in a field, reverts it |
| Return | Applies |
| Delete | Runs FreeCAD's `Std_Delete` on FreeCAD's selection |
| Right-click | Context menu at the pointer, likeliest action first |
| Wheel over a number | Steps it; Ctrl for ten times the step |

- Keyboard actions act on FreeCAD's selection, not a list's current row.
- A widget over the 3D view owns the input over its own area and passes
  everything else to the view. A wheel over a value field must not also
  zoom. FreeCAD's overlay manager filters the whole application, so you may
  need an application-level event filter installed after FreeCAD's.

## Keyboard and focus

- Tab order is reading order: left to right, then top to bottom. In QML,
  declare children in that order. A field's lead choice comes before its
  value.
- Every value control takes Tab focus: text fields, dropdowns, selectors,
  switches, check boxes.
- A QML view inside a FreeCAD task dialog joins the dialog's Tab chain:
  order the focusable widgets by position and link them with
  `QWidget.setTabOrder`.
- Draw keyboard focus as a ring in the accent colour, outside the control.
  Show it for keyboard focus only, not after a click.
- Make hover clearly visible: a fill change or a darker outline.
- Dropdowns open with Space, Return/Enter, Down, Alt+Down and F4. Up/Down
  on a closed dropdown never change its value. Closing the list returns
  focus to the dropdown.
- Selectors step with the arrow keys and keep focus when the panel
  rebuilds around them. Remember the focused property; give its new
  control the focus back unless another control already has it.
- A field keeps its edit on Tab, on a click elsewhere, and on the dialog's
  OK. OK takes no focus, so apply pending edits when it is pressed.
  Escape is the only way to drop an edit.
- When focus leaves a view (Tab out, click elsewhere, shortcut), clear its
  focus ring. A `QQuickWidget` keeps its active item when it loses focus,
  so clear it yourself. Do not clear it for the view's own popup, another
  application, or a rebuild.

## Controls

| Value | Control |
| --- | --- |
| On/off | Switch (not a check box, in most places) |
| 2–4 choices that change the result's shape | Segmented control |
| Longer list | Dropdown that looks clickable at rest |
| Number with unit | Value field, unit inside after the number, wheel steps it |
| Link to geometry | One chip per linked element |
| Rare or advanced | Collapsed "Everything else" group |

- Draw every state: rest, hover, pressed, keyboard focus, on/selected,
  read-only, and mixed (several objects with different values).
- Labels are short ("Merge faces"). Explanations go in tooltips or hints.
- Hide a value that cannot change in the current mode. Show it read-only
  only if seeing it helps.
- The same control behaves the same everywhere it appears.
- In QML, import `QtQuick.Controls.Basic` by name and restyle it from the
  theme, or draw small controls from primitives, so FreeCAD's widget
  stylesheet cannot reach in.

## Task panels and property layouts

- Describe each feature's layout once, declaratively (TOML, JSON or a
  Python table), and drive both the task panel and any property editor
  from it.
- Lay a feature out as heading-less cards in the order a user thinks:
  what is used (profile, path); how far and how (shape-changing choice at
  the top); less common options; result options.
- Show a field only in the modes that use it. Hide properties the feature
  ignores. Keep every unnamed property reachable in an "Everything else"
  group.
- Map every raw enumeration value the user sees to a short, translatable
  label.
- Write one layout for several FreeCAD versions: skip names a version
  lacks. Detect features with `hasattr`; never compare version numbers.
- Keep FreeCAD's task dialog, preview and OK/Cancel. Replace only the
  parameters box. While the task is open the dialog owns the feature and
  writes every field back on OK, so edit through its widgets: set a
  `QuantitySpinBox` by `rawValue`, never by text. Those widgets may be
  hidden; code that reads them must not require them to be visible.
- Read the feature's FreeCAD wiki page and its `.ui` file first. Take
  property names, enumeration values and widget object names from them,
  not from memory.

## Information and messages

- Show a mark only for a problem. Give severity a shape (ring, triangle,
  disc) before a colour.
- After the addon acts for the user, show a short banner with Undo
  ("Moved Pocket after Pad · Undo"). Fade it after about 6 s; keep it while
  hovered. Undo works only until anything else happens.
- Report partial success per item, with what would work instead (the
  largest size that fits).
- Errors name the cause and the fix: "Pocket003 has invalid geometry,
  made by Fillet007; fix Fillet007 first."
- Elide names only where the full name is a hover away.
- Diagnostics go to the Report view, untranslated. Anything the user must
  act on goes in the interface, translated.

## Visual design

- Read colours from FreeCAD's active stylesheet, not
  `QApplication.palette()`. Expose them through one theme object.
- Use theme tokens (`accent`, `text`, `textDim`, `hover`, `border`,
  `background`, `danger`, row height, font sizes). No hex literals, no
  fixed pixel sizes that should scale with the font.
- Update live when the theme or the panel's placement changes.
- Test light and dark, docked, FreeCAD overlay mode, and over the 3D view.
- Contrast: text ≥ 4.5:1, interactive borders ≥ 3:1.
- Give every state a non-colour cue: shape, dashed vs solid, italic,
  strike-through.
- Stay quiet: thin borders, radii of 3–6 px, one accent colour.

## Integrating with FreeCAD

- Use FreeCAD's commands, selection, task dialog and property view; put
  back anything you move.
- Wrap each user action in one transaction (one undo step).
- Where FreeCAD already has a preference, read and write FreeCAD's
  parameter instead of keeping a copy. A preference page that edits a
  shared value writes it only if it changed on that page.
- Keep your own settings under `BaseApp/Preferences/Mod/<Addon>`, read
  through one module with defaults that never raises.
- Record every FreeCAD parameter you change and restore it on uninstall.
- Give observers, event filters and timers a teardown path, so the addon
  can be reloaded without restarting FreeCAD.
- Your dock appears in View > Panels with a correct tick and working
  toggle, in every placement. Hide helper docks from those menus with
  `toggleViewAction().setVisible(False)`.
- A widget placed inside a 3D view moves out when the view starts
  closing, and back in if the close is cancelled.
- Import workbench modules (`Part`, `pivy.coin`) inside the functions that
  use them, so modules import headlessly.

## Translation

- Use FreeCAD's term where it has one ("Pad", "Body"). Name your own tools
  "<Addon> <term>".
- Labels, menus, buttons and settings: as short as the language allows.
  Tooltips may be full sentences.
- Python: `translate("Context", "Text")` with literal arguments. QML:
  `qsTr()`. Translate whole sentences with placeholders, never fragments.
- Retranslate everything on a live language change; never cache
  translated text.
- Name translation files with FreeCAD's language codes (`<Addon>_de.ts`,
  `<Addon>_es-ES.ts`).

## Crash traps (hard rules)

- Never destroy a QML object from inside its own signal handler; defer
  with `Qt.callLater`.
- Never let a Python exception escape a Qt event handler; it kills
  FreeCAD.
- Give QML objects created with `createObject` an owner when they are not
  visual items (menus, submenus); the JS engine can collect unowned ones
  while still in use.
- Tear a QML view down by deleting its `QQuickWidget`, never by nulling a
  context property.
- Drive a `Repeater` whose delegates hold edits by a count, not a list
  that is rebuilt.
- Use `singleTapped`/`doubleTapped`, not `tapped`, when both mean
  something.
- Close a choice list before emitting the choice.
- Use a `Qt::ToolTip` window, not `Popup.Window`, for suggestions beside a
  field (a popup window grabs the keyboard).
- On Wayland, open popups from a 1 px anchor item at the click point.
- PySide6 enums: use `.value`, not `int()`.

## Checklist before handing back a change

- Every control: hover, press, focus and new state at once; work after.
- Tab: every control, reading order, into the host dialog's widgets.
- Focus ring: keyboard only; gone when focus leaves.
- Edits survive Tab, click elsewhere, OK and rebuilds; Escape reverts.
- Only applicable fields shown; nothing unreachable.
- One undo step per action.
- Messages say what happened and what to do; errors name the cause.
- Theme tokens only; checked light, dark, docked, overlay.
- Non-colour cues; contrast met.
- All user-facing text translatable and live-retranslated.
- FreeCAD preferences reused; uninstall restores what changed.
- Widgets over the 3D view take only their own input.
- Say how it was verified: unit tests, headless, or a running FreeCAD.
  Never imply a GUI check that did not happen.
